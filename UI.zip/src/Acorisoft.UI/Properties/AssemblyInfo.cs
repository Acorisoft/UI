using System.Windows;
using System.Windows.Markup;

[assembly: ThemeInfo(ResourceDictionaryLocation.None , ResourceDictionaryLocation.SourceAssembly)]
[assembly: XmlnsDefinition("https://github.com/Acorisoft/UI" , "Acorisoft.UI.Buttons")]
[assembly: XmlnsDefinition("https://github.com/Acorisoft/UI" , "Acorisoft.UI.Controls")]
[assembly: XmlnsDefinition("https://github.com/Acorisoft/UI" , "Acorisoft.UI.Panels")]
[assembly: XmlnsDefinition("https://github.com/Acorisoft/UI" , "Acorisoft.UI.Windows")]
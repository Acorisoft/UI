﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Acorisoft.UI.Buttons
{
    public enum ButtonMode
    {
        Solid,
        Outline,
        CTA,
        Opacity,
        Transparent,
        Link,
        FadeIn,
        FadeOut
    }
}
